from django.db import models
from profiles.tenancy import StoreOwnedModel
from django.conf import settings
from django.utils import timezone

class ExpenseCategory(StoreOwnedModel):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name_plural = "Expense Categories"
        ordering = ['name']
        constraints = [models.UniqueConstraint(fields=['store', 'name'], name='uniq_expensecategory_name_per_store')]

    def __str__(self):
        return self.name

class Expense(StoreOwnedModel):
    category = models.ForeignKey(ExpenseCategory, on_delete=models.CASCADE, related_name='expenses')
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    description = models.TextField(blank=True, null=True)
    date = models.DateField(default=timezone.now)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-created_at']

    def __str__(self):
        return f"{self.category.name}: Rs. {self.amount} ({self.date})"
