"""
fix_tenancy.py - 2 kaam:
  1) Category naam, Product SKU aur ExpenseCategory naam ko har Store ke andar unique banata hai
     (pehle poore system me unique the, to vendor B vendor A wala SKU nahi rakh pata tha).
  2) Users & Staff page me sirf apne Store ke users dikhata hai.

Project folder (jahan manage.py hai) me chalao:   python fix_tenancy.py
Purani files ka .bak backup banta hai.
"""
from pathlib import Path

CONS = "        constraints = [models.UniqueConstraint(fields=['store', 'name'], name='%s')]\n"
CONS_SKU = "        constraints = [models.UniqueConstraint(fields=['store', 'sku'], name='uniq_product_sku_per_store')]\n"

USERS_OLD = "    users = User.objects.all().order_by('-date_joined')\n"
USERS_NEW = """    store_id = getattr(getattr(request.user, 'profile', None), 'store_id', None)
    if request.user.is_superuser and store_id is None:
        users = User.objects.all().order_by('-date_joined')   # platform admin: sab users
    elif store_id:
        users = User.objects.filter(profile__store_id=store_id).order_by('-date_joined')  # sirf apne store ke
    else:
        users = User.objects.none()
"""

EDITS = {
    'products/models.py': [
        ("    name = models.CharField(max_length=100, unique=True)\n",
         "    name = models.CharField(max_length=100)\n"),
        ("        verbose_name_plural = \"Categories\"\n        ordering = ['name']\n",
         "        verbose_name_plural = \"Categories\"\n        ordering = ['name']\n" + CONS % 'uniq_category_name_per_store'),
        ("    sku = models.CharField(max_length=50, unique=True)\n",
         "    sku = models.CharField(max_length=50)\n"),
        ("        ordering = ['-created_at']\n",
         "        ordering = ['-created_at']\n" + CONS_SKU),
    ],
    'expenses/models.py': [
        ("    name = models.CharField(max_length=100, unique=True)\n",
         "    name = models.CharField(max_length=100)\n"),
        ("        verbose_name_plural = \"Expense Categories\"\n        ordering = ['name']\n",
         "        verbose_name_plural = \"Expense Categories\"\n        ordering = ['name']\n" + CONS % 'uniq_expensecategory_name_per_store'),
    ],
    'accounts/views.py': [(USERS_OLD, USERS_NEW)],
}

for rel, edits in EDITS.items():
    path = Path(rel)
    if not path.exists():
        print(f'[SKIP] {rel} nahi mili')
        continue
    text = path.read_text(encoding='utf-8')
    if 'per_store' in text or 'profile__store_id' in text:
        print(f'[OK]   {rel}: pehle se ho chuka hai')
        continue
    bad = [old.strip().splitlines()[0] for old, _ in edits if text.count(old) != 1]
    if bad:
        print(f'[SKIP] {rel}: ye line exact nahi mili (ya ek se zyada): {bad}')
        continue
    for old, new in edits:
        text = text.replace(old, new)
    bak = path.with_name(path.name + '.bak2')
    if not bak.exists():
        bak.write_bytes(path.read_bytes())
    path.write_text(text, encoding='utf-8')
    print(f'[DONE] {rel}')
print('\nAb chalao:\n  python manage.py makemigrations\n  python manage.py migrate')