from django.db import models
from profiles.tenancy import StoreOwnedModel
from django.conf import settings

class Category(StoreOwnedModel):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ['name']
        constraints = [models.UniqueConstraint(fields=['store', 'name'], name='uniq_category_name_per_store')]

    def __str__(self):
        return self.name

class Product(StoreOwnedModel):
    name = models.CharField(max_length=200)
    sku = models.CharField(max_length=50)
    barcode = models.CharField(max_length=50, blank=True, null=True, db_index=True)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True, related_name='products')
    purchase_price = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    selling_price = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    stock = models.IntegerField(default=0)
    minimum_stock = models.IntegerField(default=5)
    image = models.ImageField(upload_to='products/', blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='products')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        constraints = [models.UniqueConstraint(fields=['store', 'sku'], name='uniq_product_sku_per_store')]

    @property
    def is_low_stock(self):
        return self.stock <= self.minimum_stock

    def save(self, *args, **kwargs):
        if not self.barcode:
            import random
            import string
            while True:
                # Generate a 12-digit barcode for EAN-13
                barcode = ''.join(random.choices(string.digits, k=12))
                if not Product.objects.filter(barcode=barcode).exists():
                    self.barcode = barcode
                    break
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.name} ({self.sku})"
