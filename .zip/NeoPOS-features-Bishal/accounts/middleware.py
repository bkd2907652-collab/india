# accounts/middleware.py  (aapki existing SubscriptionAccessMiddleware ka updated version)
from django.http import JsonResponse
from django.shortcuts import redirect


class SubscriptionAccessMiddleware:
    """Send expired users to payment proof submission before protected app pages."""

    ALLOWED_PREFIXES = (
        '/admin/',
        '/accounts/upgrade/',
        '/accounts/activate-license/',
        '/accounts/profile/',
        '/profile/',                      # NEW: profiles app ka page
        '/accounts/login/',
        '/accounts/register/',
        '/accounts/logout/',
        '/login/',
        '/register/',
        '/logout/',
        '/static/',
        '/media/',
        '/about/',
        '/pricing/',
        '/contact/',
        '/pos-showcase/',
        '/privacy-policy/',
        '/terms-of-service/',
        '/security/',
        '/hardware-support/',
    )

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated and not request.user.has_active_access:
            if not request.path.startswith(self.ALLOWED_PREFIXES):
                # NEW: fetch/AJAX calls (jaise POS terminal) ko redirect ki jagah JSON error do
                if (request.headers.get('x-requested-with') == 'XMLHttpRequest'
                        or 'application/json' in request.headers.get('accept', '')):
                    return JsonResponse({'error': 'license_expired'}, status=403)
                return redirect('upgrade_request')
        return self.get_response(request)