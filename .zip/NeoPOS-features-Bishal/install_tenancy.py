#!/usr/bin/env python
"""
install_tenancy.py - vendor-wise data isolation (ek vendor ka data dusre ko na dikhe) ek saath laga deta hai.

Project folder (jahan manage.py hai) me chalao:
    python install_tenancy.py                  # sirf dikhata hai kya badlega (kuch change nahi hota)
    python install_tenancy.py --apply          # asli me change karta hai (purani files ka .bak backup banta hai)
    python install_tenancy.py --apply --skip ModelName   # kisi model ko chhodna ho to
"""
import argparse
import re
import sys
from pathlib import Path

APPS = ['products', 'inventory', 'sales', 'purchases', 'expenses', 'customers', 'suppliers', 'support']
MIDDLEWARE_PATH = 'profiles.tenancy.StoreScopeMiddleware'
IMPORT_LINE = 'from profiles.tenancy import StoreOwnedModel'

TENANCY = r'''"""Har vendor (Store) ka data alag rakhne ka system.

Kaise kaam karta hai:
- Har business model StoreOwnedModel se bante hain, to unme `store` field aa jata hai.
- StoreOwnedModel.objects apne aap sirf logged-in user ke store ka data deta hai.
  Isliye views me `.filter(store=...)` lagane ki zarurat nahi.
- Naya data save hote hi user ka store apne aap lag jata hai.
- Login nahi hai ya store nahi mila to koi bhi vendor data nahi dikhta.
- Superuser (jiska koi store nahi) sab kuch dekh sakta hai.
"""
import threading

from django.core.exceptions import ObjectDoesNotExist
from django.db import models

_local = threading.local()


def activate(store_id=None, unrestricted=False):
    _local.active = True
    _local.store_id = store_id
    _local.unrestricted = unrestricted


def deactivate():
    _local.active = False
    _local.store_id = None
    _local.unrestricted = False


def current_store_id():
    """Chalu request ke user ka store id. Superuser ya request ke bahar: None."""
    if getattr(_local, 'active', False) and not getattr(_local, 'unrestricted', False):
        return getattr(_local, 'store_id', None)
    return None


class StoreManager(models.Manager):
    def get_queryset(self):
        qs = super().get_queryset()
        if getattr(_local, 'active', False) and not getattr(_local, 'unrestricted', False):
            store_id = getattr(_local, 'store_id', None)
            return qs.filter(store_id=store_id) if store_id else qs.none()
        return qs


class StoreOwnedModel(models.Model):
    # editable=False: forms me store nahi dikhta, to koi dusre vendor ka store chun nahi sakta
    store = models.ForeignKey(
        'profiles.Store', null=True, blank=True, editable=False,
        on_delete=models.CASCADE, related_name='+',
    )
    objects = StoreManager()       # sirf apne store ka data
    all_stores = models.Manager()  # sab ka data (sirf admin/management commands ke liye)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if self.store_id is None:
            self.store_id = current_store_id()
        super().save(*args, **kwargs)


def _store_id_for(user):
    try:
        return user.profile.store_id
    except ObjectDoesNotExist:
        return None


class StoreScopeMiddleware:
    """Har request par batata hai ki kaun sa store active hai."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        user = getattr(request, 'user', None)
        if user is not None and user.is_authenticated:
            store_id = _store_id_for(user)
            if user.is_superuser and store_id is None:
                activate(unrestricted=True)
            else:
                activate(store_id=store_id)
        else:
            activate(store_id=None)
        try:
            return self.get_response(request)
        finally:
            deactivate()
'''
PROFILE_MODELS = r'''# profiles/models.py
from decimal import Decimal

from django.conf import settings
from django.db import models


class Store(models.Model):
    """Ek vendor ki dukaan. Is vendor ke saare users aur saara data isi se jude hote hain."""
    name = models.CharField(max_length=150)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class Profile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile')
    store = models.ForeignKey(Store, null=True, blank=True, on_delete=models.SET_NULL, related_name='members')

    # Personal
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True)
    address = models.TextField(blank=True)

    # Business / shop (invoice aur receipt par yahi aayega)
    business_name = models.CharField('Shop / business name', max_length=150, blank=True)
    business_logo = models.ImageField('Shop logo', upload_to='logos/', blank=True, null=True)
    business_phone = models.CharField('Shop phone', max_length=20, blank=True)
    business_email = models.EmailField('Shop email', blank=True)
    business_address = models.TextField('Shop address', blank=True)
    gstin = models.CharField('GSTIN / PAN / VAT number', max_length=30, blank=True)

    # Billing defaults
    currency_symbol = models.CharField(max_length=5, default='₹')
    default_tax_rate = models.DecimalField('Default tax rate (%)', max_digits=5, decimal_places=2, default=Decimal('0'))
    invoice_prefix = models.CharField(max_length=10, default='INV-')
    receipt_footer = models.TextField('Receipt footer message', blank=True)

    def __str__(self):
        return f'Profile of {self.user}'
'''
PROFILE_SIGNALS = r'''# profiles/signals.py
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import Profile, Store
from .tenancy import current_store_id


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_profile(sender, instance, created, **kwargs):
    if not created:
        return
    # Vendor ke login se staff banaya to wo usi vendor ke store me jata hai.
    # Nayi registration par naya vendor = nayi Store. Superuser ko store nahi milta.
    store_id = current_store_id()
    if store_id is None and not instance.is_superuser:
        name = (getattr(instance, 'store_name', '') or instance.get_username())[:150]
        store_id = Store.objects.create(name=name).pk
    Profile.objects.get_or_create(user=instance, defaults={'store_id': store_id})
'''
COMMAND = r'''# profiles/management/commands/assign_store_data.py
from django.apps import apps
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.db import transaction

from profiles.models import Profile, Store
from profiles.tenancy import StoreOwnedModel

OWNER_FIELDS = ('user', 'created_by', 'owner', 'added_by', 'cashier', 'recorded_by', 'staff')


class Command(BaseCommand):
    help = 'Purane users ko Store deta hai aur purane data (jiska store khali hai) ko sahi Store se jodta hai.'

    def add_arguments(self, parser):
        parser.add_argument('--default-store', type=int,
                            help='Jin purane rows ka owner nahi mil paya, unhe is Store id me daalo.')
        parser.add_argument('--dry-run', action='store_true', help='Sirf dikhao, kuch save mat karo.')

    @transaction.atomic
    def handle(self, *args, **opts):
        User = get_user_model()

        # 1) Har normal user ko Profile aur Store do
        made = 0
        for user in User.objects.filter(is_superuser=False):
            profile, _ = Profile.objects.get_or_create(user=user)
            if profile.store_id is None:
                name = (getattr(user, 'store_name', '') or user.get_username())[:150]
                profile.store = Store.objects.create(name=name)
                profile.save(update_fields=['store'])
                made += 1
        self.stdout.write(f'Naye Store bane: {made}')

        # 2) Purana data: pehle owner field se, phir parent row se store lo
        scoped = [m for m in apps.get_models() if issubclass(m, StoreOwnedModel) and not m._meta.abstract]
        owners = dict(Profile.objects.filter(store__isnull=False).values_list('user_id', 'store_id'))
        store_ids = set(owners.values())
        for _ in range(4):
            changed = 0
            for model in scoped:
                for f in model._meta.get_fields():
                    if not (f.is_relation and f.many_to_one):
                        continue
                    qs = model.all_stores.filter(store__isnull=True)
                    if f.related_model == User and f.name in OWNER_FIELDS:
                        for uid, sid in owners.items():
                            changed += qs.filter(**{f.attname: uid}).update(store_id=sid)
                    elif f.related_model in scoped:
                        for sid in store_ids:
                            changed += qs.filter(**{f'{f.name}__store_id': sid}).update(store_id=sid)
            if not changed:
                break

        # 3) Jo bach gaya
        default = opts.get('default_store')
        if default:
            if not Store.objects.filter(pk=default).exists():
                raise SystemExit(f'Store id {default} nahi mili.')
            for model in scoped:
                model.all_stores.filter(store__isnull=True).update(store_id=default)
        for model in scoped:
            left = model.all_stores.filter(store__isnull=True).count()
            label = f'{model._meta.app_label}.{model.__name__}'
            self.stdout.write(f'  {label}: {left} row(s) bina store' if left else f'  {label}: ok')
        if opts['dry_run']:
            transaction.set_rollback(True)
            self.stdout.write('DRY-RUN: kuch save nahi hua.')
'''

FILES = {
    'profiles/tenancy.py': TENANCY,
    'profiles/models.py': PROFILE_MODELS,
    'profiles/signals.py': PROFILE_SIGNALS,
    'profiles/management/__init__.py': '',
    'profiles/management/commands/__init__.py': '',
    'profiles/management/commands/assign_store_data.py': COMMAND,
}

CLASS_RE = re.compile(r'^class\s+(\w+)\(\s*models\.Model\s*\):', re.M)
ANY_CLASS_RE = re.compile(r'^class\s+(\w+)\((.*)\):', re.M)
MODEL_WARN = re.compile(r'unique=True|unique_together|UniqueConstraint|\bobjects\s*=|Manager\(')
CODE_WARN = re.compile(r'\.raw\(|cursor\(|bulk_create|bulk_update|_base_manager')
USER_WARN = re.compile(r'User\.objects|get_user_model')


class Reporter:
    def __init__(self, apply):
        self.apply = apply
        self.warnings = []

    def log(self, msg):
        print(('  [ok] ' if self.apply else '  [dikhao] ') + msg)

    def warn(self, msg):
        self.warnings.append(msg)

    def write(self, path, text):
        if self.apply:
            if path.exists():
                bak = path.with_name(path.name + '.bak')
                if not bak.exists():
                    bak.write_bytes(path.read_bytes())
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding='utf-8')


def lines_matching(text, regex):
    return [f'{i}: {line.strip()}' for i, line in enumerate(text.splitlines(), 1) if regex.search(line)]


def install_files(root, rep):
    print('\n1) Naye/replace hone wali files')
    for rel, text in FILES.items():
        path = root / rel
        action = 'replace' if path.exists() else 'nayi file'
        rep.write(path, text)
        rep.log(f'{rel} ({action})')


def patch_settings(root, rep):
    print('\n2) settings.py me middleware')
    manage = (root / 'manage.py').read_text(encoding='utf-8')
    m = re.search(r'DJANGO_SETTINGS_MODULE[\'"],\s*[\'"]([\w.]+)[\'"]', manage)
    if not m:
        rep.warn('settings file nahi mili. MIDDLEWARE me AuthenticationMiddleware ke neeche ye line khud jodo: ' + f"'{MIDDLEWARE_PATH}',")
        return
    path = root / (m.group(1).replace('.', '/') + '.py')
    if not path.exists():
        path = root / m.group(1).replace('.', '/') / '__init__.py'
    text = path.read_text(encoding='utf-8')
    if MIDDLEWARE_PATH in text:
        rep.log(f'{path.relative_to(root)}: middleware pehle se hai')
        return
    pat = re.compile(r'^([ \t]*)([\'"])django\.contrib\.auth\.middleware\.AuthenticationMiddleware\2,[^\n]*\n', re.M)
    mm = pat.search(text)
    if not mm:
        rep.warn(f"{path.relative_to(root)} me AuthenticationMiddleware nahi mili. Uske neeche ye line khud jodo: '{MIDDLEWARE_PATH}',")
        return
    new = text[:mm.end()] + f"{mm.group(1)}'{MIDDLEWARE_PATH}',\n" + text[mm.end():]
    rep.write(path, new)
    rep.log(f'{path.relative_to(root)}: AuthenticationMiddleware ke neeche middleware jodi')


def patch_models(root, app, skip, rep):
    path = root / app / 'models.py'
    if not path.exists():
        rep.warn(f'{app}/models.py nahi mili, chhod diya')
        return
    text = path.read_text(encoding='utf-8')
    if 'StoreOwnedModel' in text:
        rep.log(f'{app}/models.py: pehle se patched')
        return
    names = [n for n in CLASS_RE.findall(text) if n not in skip]
    others = [(n, b) for n, b in ANY_CLASS_RE.findall(text) if n not in names and n not in skip and not re.fullmatch(r'\s*models\.Model\s*', b)]
    for n, b in others:
        rep.warn(f'{app}/models.py: class {n}({b}) badla nahi gaya. Agar ye business data model hai to khud check karo.')
    if not names:
        rep.log(f'{app}/models.py: badalne layak model nahi mila')
        return
    pat = re.compile(r'^class\s+(' + '|'.join(re.escape(n) for n in names) + r')\(\s*models\.Model\s*\):', re.M)
    new = pat.sub(r'class \1(StoreOwnedModel):', text)
    im = re.search(r'^from django\.db import models[^\n]*\n', new, re.M)
    if not im or im.group(0).rstrip().endswith('('):
        rep.warn(f'{app}/models.py: import line samajh nahi aayi. Upar ye line khud jodo: {IMPORT_LINE}')
        return
    new = new[:im.end()] + IMPORT_LINE + '\n' + new[im.end():]
    rep.write(path, new)
    rep.log(f'{app}/models.py: {", ".join(names)}')
    for hit in lines_matching(new, MODEL_WARN):
        rep.warn(f'{app}/models.py line {hit}   <- unique/manager: dekho, ye har store ke andar alag hona chahiye ya nahi')


def scan_code(root, rep):
    for app in APPS + ['reports']:
        for fname in ('views.py', 'forms.py'):
            p = root / app / fname
            if p.exists():
                for hit in lines_matching(p.read_text(encoding='utf-8'), CODE_WARN):
                    rep.warn(f'{app}/{fname} line {hit}   <- raw SQL/bulk: store filter apne aap nahi lagta')
    p = root / 'accounts' / 'views.py'
    if p.exists():
        for hit in lines_matching(p.read_text(encoding='utf-8'), USER_WARN):
            rep.warn(f'accounts/views.py line {hit}   <- users ki list/edit/delete yahan filter karni hogi')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--skip', nargs='*', default=[])
    ap.add_argument('--apps', nargs='*', default=APPS)
    args = ap.parse_args()
    root = Path.cwd()
    if not (root / 'manage.py').exists() or not (root / 'profiles').is_dir():
        sys.exit('Ye script project folder (jahan manage.py hai) me chalao. profiles app bhi honi chahiye.')

    rep = Reporter(args.apply)
    print('MODE:', 'APPLY (asli change)' if args.apply else 'DRY-RUN (kuch change nahi hoga)')
    install_files(root, rep)
    patch_settings(root, rep)
    print('\n3) Models (models.Model -> StoreOwnedModel)')
    for app in args.apps:
        patch_models(root, app, set(args.skip), rep)
    scan_code(root, rep)

    if rep.warnings:
        print('\n4) DHYAN DO (ye manual dekhna hai)')
        for w in rep.warnings:
            print('  !', w)
    print('\nAage ke commands:' if args.apply else '\nSab theek lage to ye chalao:')
    if not args.apply:
        print('  python install_tenancy.py --apply')
    print('  python manage.py makemigrations')
    print('  python manage.py migrate')
    print('  python manage.py assign_store_data --dry-run')
    print('  python manage.py assign_store_data')


if __name__ == '__main__':
    main()