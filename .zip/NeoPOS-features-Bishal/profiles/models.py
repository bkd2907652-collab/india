# profiles/models.py
from decimal import Decimal

from django.conf import settings
from django.db import models


class Store(models.Model):
    """Ek vendor ki dukaan. Is vendor ke saare users aur saara data isi se jude hote hain."""
    name = models.CharField(max_length=150)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class Profile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile')
    store = models.ForeignKey(Store, null=True, blank=True, on_delete=models.SET_NULL, related_name='members')

    # Personal
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True)
    address = models.TextField(blank=True)

    # Business / shop (invoice aur receipt par yahi aayega)
    business_name = models.CharField('Shop / business name', max_length=150, blank=True)
    business_logo = models.ImageField('Shop logo', upload_to='logos/', blank=True, null=True)
    business_phone = models.CharField('Shop phone', max_length=20, blank=True)
    business_email = models.EmailField('Shop email', blank=True)
    business_address = models.TextField('Shop address', blank=True)
    gstin = models.CharField('GSTIN / PAN / VAT number', max_length=30, blank=True)

    # Billing defaults
    currency_symbol = models.CharField(max_length=5, default='₹')
    default_tax_rate = models.DecimalField('Default tax rate (%)', max_digits=5, decimal_places=2, default=Decimal('0'))
    invoice_prefix = models.CharField(max_length=10, default='INV-')
    receipt_footer = models.TextField('Receipt footer message', blank=True)

    def __str__(self):
        return f'Profile of {self.user}'
