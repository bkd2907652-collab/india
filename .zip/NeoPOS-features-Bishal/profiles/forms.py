# profiles/forms.py
from django import forms
from django.contrib.auth import get_user_model

from .models import Profile

PROFILE_SECTIONS = [
    ('Personal details', ['first_name', 'last_name', 'email', 'phone', 'address']),
    ('Business details', ['business_name', 'business_phone', 'business_email', 'gstin', 'business_logo', 'business_address']),
    ('Billing & invoice settings', ['currency_symbol', 'default_tax_rate', 'invoice_prefix', 'receipt_footer']),
]


class UserBasicsForm(forms.ModelForm):
    """User model ke naam aur email."""
    class Meta:
        model = get_user_model()
        fields = ['first_name', 'last_name', 'email']


class ProfileForm(forms.ModelForm):
    """Baaki sab kuch Profile model se."""
    class Meta:
        model = Profile
        fields = [
            'avatar', 'phone', 'address',
            'business_name', 'business_logo', 'business_phone', 'business_email', 'business_address', 'gstin',
            'currency_symbol', 'default_tax_rate', 'invoice_prefix', 'receipt_footer',
        ]
        widgets = {
            'avatar': forms.FileInput(attrs={'accept': 'image/*', 'hidden': True}),
            'business_logo': forms.FileInput(attrs={'accept': 'image/*'}),
            'address': forms.Textarea(attrs={'rows': 2}),
            'business_address': forms.Textarea(attrs={'rows': 2}),
            'receipt_footer': forms.Textarea(attrs={'rows': 2}),
        }