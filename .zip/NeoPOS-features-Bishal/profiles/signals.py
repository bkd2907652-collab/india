# profiles/signals.py
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import Profile, Store
from .tenancy import current_store_id


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_profile(sender, instance, created, **kwargs):
    if not created:
        return
    # Vendor ke login se staff banaya to wo usi vendor ke store me jata hai.
    # Nayi registration par naya vendor = nayi Store. Superuser ko store nahi milta.
    store_id = current_store_id()
    if store_id is None and not instance.is_superuser:
        name = (getattr(instance, 'store_name', '') or instance.get_username())[:150]
        store_id = Store.objects.create(name=name).pk
    Profile.objects.get_or_create(user=instance, defaults={'store_id': store_id})
