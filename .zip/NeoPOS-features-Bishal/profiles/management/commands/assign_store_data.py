# profiles/management/commands/assign_store_data.py
from django.apps import apps
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.db import transaction

from profiles.models import Profile, Store
from profiles.tenancy import StoreOwnedModel

OWNER_FIELDS = ('user', 'created_by', 'owner', 'added_by', 'cashier', 'recorded_by', 'staff')


class Command(BaseCommand):
    help = 'Purane users ko Store deta hai aur purane data (jiska store khali hai) ko sahi Store se jodta hai.'

    def add_arguments(self, parser):
        parser.add_argument('--default-store', type=int,
                            help='Jin purane rows ka owner nahi mil paya, unhe is Store id me daalo.')
        parser.add_argument('--dry-run', action='store_true', help='Sirf dikhao, kuch save mat karo.')

    @transaction.atomic
    def handle(self, *args, **opts):
        User = get_user_model()

        # 1) Har normal user ko Profile aur Store do
        made = 0
        for user in User.objects.filter(is_superuser=False):
            profile, _ = Profile.objects.get_or_create(user=user)
            if profile.store_id is None:
                name = (getattr(user, 'store_name', '') or user.get_username())[:150]
                profile.store = Store.objects.create(name=name)
                profile.save(update_fields=['store'])
                made += 1
        self.stdout.write(f'Naye Store bane: {made}')

        # 2) Purana data: pehle owner field se, phir parent row se store lo
        scoped = [m for m in apps.get_models() if issubclass(m, StoreOwnedModel) and not m._meta.abstract]
        owners = dict(Profile.objects.filter(store__isnull=False).values_list('user_id', 'store_id'))
        store_ids = set(owners.values())
        for _ in range(4):
            changed = 0
            for model in scoped:
                for f in model._meta.get_fields():
                    if not (f.is_relation and f.many_to_one):
                        continue
                    qs = model.all_stores.filter(store__isnull=True)
                    if f.related_model == User and f.name in OWNER_FIELDS:
                        for uid, sid in owners.items():
                            changed += qs.filter(**{f.attname: uid}).update(store_id=sid)
                    elif f.related_model in scoped:
                        for sid in store_ids:
                            changed += qs.filter(**{f'{f.name}__store_id': sid}).update(store_id=sid)
            if not changed:
                break

        # 3) Jo bach gaya
        default = opts.get('default_store')
        if default:
            if not Store.objects.filter(pk=default).exists():
                raise SystemExit(f'Store id {default} nahi mili.')
            for model in scoped:
                model.all_stores.filter(store__isnull=True).update(store_id=default)
        for model in scoped:
            left = model.all_stores.filter(store__isnull=True).count()
            label = f'{model._meta.app_label}.{model.__name__}'
            self.stdout.write(f'  {label}: {left} row(s) bina store' if left else f'  {label}: ok')
        if opts['dry_run']:
            transaction.set_rollback(True)
            self.stdout.write('DRY-RUN: kuch save nahi hua.')
