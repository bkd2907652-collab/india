"""Har vendor (Store) ka data alag rakhne ka system.

Kaise kaam karta hai:
- Har business model StoreOwnedModel se bante hain, to unme `store` field aa jata hai.
- StoreOwnedModel.objects apne aap sirf logged-in user ke store ka data deta hai.
  Isliye views me `.filter(store=...)` lagane ki zarurat nahi.
- Naya data save hote hi user ka store apne aap lag jata hai.
- Login nahi hai ya store nahi mila to koi bhi vendor data nahi dikhta.
- Superuser (jiska koi store nahi) sab kuch dekh sakta hai.
"""
import threading

from django.core.exceptions import ObjectDoesNotExist
from django.db import models

_local = threading.local()


def activate(store_id=None, unrestricted=False):
    _local.active = True
    _local.store_id = store_id
    _local.unrestricted = unrestricted


def deactivate():
    _local.active = False
    _local.store_id = None
    _local.unrestricted = False


def current_store_id():
    """Chalu request ke user ka store id. Superuser ya request ke bahar: None."""
    if getattr(_local, 'active', False) and not getattr(_local, 'unrestricted', False):
        return getattr(_local, 'store_id', None)
    return None


class StoreManager(models.Manager):
    def get_queryset(self):
        qs = super().get_queryset()
        if getattr(_local, 'active', False) and not getattr(_local, 'unrestricted', False):
            store_id = getattr(_local, 'store_id', None)
            return qs.filter(store_id=store_id) if store_id else qs.none()
        return qs


class StoreOwnedModel(models.Model):
    # editable=False: forms me store nahi dikhta, to koi dusre vendor ka store chun nahi sakta
    store = models.ForeignKey(
        'profiles.Store', null=True, blank=True, editable=False,
        on_delete=models.CASCADE, related_name='+',
    )
    objects = StoreManager()       # sirf apne store ka data
    all_stores = models.Manager()  # sab ka data (sirf admin/management commands ke liye)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if self.store_id is None:
            self.store_id = current_store_id()
        super().save(*args, **kwargs)


def _store_id_for(user):
    try:
        return user.profile.store_id
    except ObjectDoesNotExist:
        return None


class StoreScopeMiddleware:
    """Har request par batata hai ki kaun sa store active hai."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        user = getattr(request, 'user', None)
        if user is not None and user.is_authenticated:
            store_id = _store_id_for(user)
            if user.is_superuser and store_id is None:
                activate(unrestricted=True)
            else:
                activate(store_id=store_id)
        else:
            activate(store_id=None)
        try:
            return self.get_response(request)
        finally:
            deactivate()
