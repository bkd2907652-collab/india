# profiles/views.py
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.shortcuts import redirect, render

from .forms import PROFILE_SECTIONS, ProfileForm, UserBasicsForm
from .models import Profile


@login_required
def profile(request):
    user = request.user
    prof, _ = Profile.objects.get_or_create(user=user)
    user_form = UserBasicsForm(instance=user)
    form = ProfileForm(instance=prof)
    pw_form = PasswordChangeForm(user)

    if request.method == 'POST':
        if 'change_password' in request.POST:
            pw_form = PasswordChangeForm(user, request.POST)
            if pw_form.is_valid():
                update_session_auth_hash(request, pw_form.save())  # password badalne par logout nahi hoga
                messages.success(request, 'Password updated.')
                return redirect('profile')
        else:
            user_form = UserBasicsForm(request.POST, instance=user)
            form = ProfileForm(request.POST, request.FILES, instance=prof)
            if user_form.is_valid() and form.is_valid():
                user_form.save()
                form.save()
                messages.success(request, 'Profile saved.')
                return redirect('profile')

    fields = {n: user_form[n] for n in user_form.fields}
    fields.update({n: form[n] for n in form.fields})
    sections = [(title, [fields[n] for n in names]) for title, names in PROFILE_SECTIONS]
    return render(request, 'profile.html', {
        'profile': prof, 'form': form, 'user_form': user_form, 'pw_form': pw_form, 'sections': sections,
    })